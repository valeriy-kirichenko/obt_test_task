from django.apps import AppConfig


class AppConf(AppConfig):
    name = 'app'
